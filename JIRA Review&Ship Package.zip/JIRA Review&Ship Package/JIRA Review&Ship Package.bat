@echo off
setlocal EnableExtensions
title JIRA Review^&Ship Package
cd /d "%~dp0"

echo ========================================
echo  JIRA Review^&Ship Package
echo  generate - review - push
echo ========================================
echo.
set /p STORY=Enter User Story key (e.g. TPQA-64): 
if "%STORY%"=="" (
  echo No story key entered. Exiting.
  exit /b 1
)

echo.
echo [1/3] Generating draft proposal from JIRA for %STORY%...
echo      ^(Set GEMINI_API_KEY in .env, or enable Ollama with JIRA_PROPOSAL_OLLAMA=1.^)
call node scripts\jira-proposal-generate.js %STORY%
if errorlevel 1 (
  echo Generate failed. Check .env JIRA_* and network.
  exit /b 1
)

echo.
echo Open the review page if you need the static file:
echo   "tests\jira-proposals\%STORY%\Test Proposals ~ %STORY%.html"
echo.
echo [2/3] Review in Chrome ^(local server^). Select tests, edit text, then click:
echo       "Submit and continue to JIRA" ^(saves selection + proposal, then closes tab^).
echo       If the tab does not close, return here anyway — the window continues after submit.
echo.
node scripts\jira-proposal-review-server.js %STORY%
if errorlevel 1 (
  echo Review server ended with an error.
  exit /b 1
)

echo.
echo [3/3] Creating selected Test Case issues in JIRA...
call node scripts\push-proposal-selection-to-jira.js %STORY% --consume-selection
if errorlevel 1 (
  echo Push failed.
  exit /b 1
)

echo.
echo Done. Keys are listed above; manifest: tests\jira-proposals\%STORY%\created-manifest.json
echo.
pause
