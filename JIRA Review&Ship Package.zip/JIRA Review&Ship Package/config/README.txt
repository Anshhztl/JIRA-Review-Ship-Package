Optional: copy flow-metadata.ts from your Salesforce automation repo into this folder as flow-metadata.ts to give the proposal LLM richer context.
