# JIRA Review&Ship Package

Draft test cases from a JIRA user story, review them in the **Review & Ship** page (light/dark mode), and create only the rows you select in JIRA.

**Start here:** open **`GETTING-STARTED.html`** in your browser.

**Settings:** edit **`.env`** in this folder. Details in **`CONFIGURATION.md`**.

## Quick commands (after `npm install`)

| Step | Command |
|------|---------|
| Generate drafts + review file | `npm run jira:proposal:generate -- YOUR-STORY-KEY` |
| Rebuild review HTML only | `npm run jira:proposal:review -- YOUR-STORY-KEY` |
| Windows full flow | Double-click **`JIRA Review&Ship Package.bat`** |
