# Configuration — JIRA Review&Ship Package

All settings are read from the **`.env`** file in the **root of this package** (the same folder as `package.json`). Open `.env`, fill in your values, and save.

Scripts also call `dotenv` with paths relative to the `scripts/` folder, which resolves to that same root `.env`.

---

## 1. Required — JIRA API

| Variable | Description |
|----------|-------------|
| `JIRA_BASE_URL` | Site URL, no trailing slash, e.g. `https://yourorg.atlassian.net` |
| `JIRA_EMAIL` | Atlassian account email used for the API token |
| `JIRA_API_TOKEN` | Create at Atlassian: **Profile → Security → Create and manage API tokens** |

If any of these are missing, scripts that call JIRA will throw a clear error.

---

## 2. Test Case creation (push)

| Variable | Default / notes |
|----------|-----------------|
| `JIRA_TEST_ISSUE_TYPE` | **Required for push:** exact JIRA issue type name for new tests (e.g. `Test`, `Test Case`). |
| `JIRA_PROJECT_KEY` | Optional; inferred from the story key prefix when possible. |
| `JIRA_TEST_CASE_PARENT_MODE` | `link_only` (default) or `try_parent` — how new tests relate to the story. |
| `JIRA_TEST_CASE_STRIP_RELATES_TO_STORY` | `1` = remove generic “Relates” after the Story–Test link is created; `0` to keep. |
| `JIRA_STORY_TC_LINK_TYPE` | Optional exact link type name; otherwise auto-detected. |
| `JIRA_STORY_TC_AFTER_CREATE` | `always` \| `never` — add Story–Test link after create. |
| `JIRA_ASSIGNEE_ACCOUNT_ID` | Optional; used for QA artifact subtasks. |

### Custom fields (Test case type, Flow, Expected Results)

If your JIRA uses custom fields, set either the **field id** or a **label** the scripts can match:

| Variable | Purpose |
|----------|---------|
| `JIRA_TEST_CASE_TYPE_FIELD` | Custom field id for “Test case type” |
| `JIRA_TEST_CASE_FLOW_FIELD` | Custom field id for “Flow” |
| `JIRA_TEST_CASE_EXPECTED_RESULTS_FIELD` | Custom field id for “Expected Results” |
| `JIRA_TEST_CASE_TYPE_FIELD_LABEL` | Display name if id not set |
| `JIRA_TEST_CASE_FLOW_FIELD_LABEL` | Display name if id not set |
| `JIRA_TEST_CASE_EXPECTED_RESULTS_LABEL` | Display name if id not set |
| `JIRA_TEST_CASE_EXPECTED_RESULTS_PLAIN` | `1` if Expected Results is plain text, not ADF |
| `JIRA_TEST_CASE_ADF_STRUCTURED` | `1` = structured ADF headings for description sections |

### QA artifact subtasks (optional)

| Variable | Purpose |
|----------|---------|
| `JIRA_QA_ARTIFACT_CREATE_SUMMARY` | Subtask summary for “creation” artifact |
| `JIRA_QA_ARTIFACT_EXECUTE_SUMMARY` | Subtask summary for “execution” artifact |
| `JIRA_QA_ARTIFACT_CREATE_DONE_TRANSITION` | Transition name to close create artifact |
| `JIRA_SUBTASK_ISSUE_TYPE` | Issue type for subtasks (e.g. `Sub-task`) |

---

## 3. Proposal review UI — picklist values

These must match **exactly** the allowed values in your JIRA picklists (case and spelling):

| Variable | Example |
|----------|---------|
| `JIRA_PROPOSAL_TEST_CASE_TYPES` | `Functional,Data,Boundary,UI/UX,Security,Performance,E2E,Integration` |
| `JIRA_PROPOSAL_TEST_FLOWS` | `Positive,Negative,Boundary,Combined` |

If omitted, built-in defaults are used (see `scripts/lib/jira-proposal-options.js`).

---

## 4. LLM — draft proposals and pointer-style acceptance criteria

| Variable | Values / notes |
|----------|----------------|
| `JIRA_PROPOSAL_LLM` | `auto` (default), `gemini`, `ollama`, `openai`, `none`. `none` = heuristic only, no API calls. |
| `GEMINI_API_KEY` or `GOOGLE_AI_API_KEY` | [Google AI Studio](https://aistudio.google.com/apikey) — used when mode is `auto` or `gemini`. |
| `GEMINI_MODEL` | e.g. `gemini-flash-latest` |
| `JIRA_PROPOSAL_OLLAMA` | Set to `1` to prefer local Ollama in `auto` chain. |
| `OLLAMA_BASE_URL` | Default `http://127.0.0.1:11434` |
| `OLLAMA_MODEL` | e.g. `llama3.2` |
| `OPENAI_API_KEY` | Used when `openai` or in `auto` after Gemini/Ollama. |
| `OPENAI_MODEL` | e.g. `gpt-4o-mini` |
| `OPENAI_BASE_URL` | Optional custom OpenAI-compatible endpoint |
| `JIRA_PROPOSAL_USE_AI` | `0` = never use OpenAI in `auto` chain |

---

## 5. Optional — Chrome (Windows pipeline)

| Variable | Purpose |
|----------|---------|
| `CHROME_PATH` | Full path to `chrome.exe` if not in default Program Files. Used when the review server launches a browser. |

---

## 6. Optional — richer LLM context

Place a **`config/flow-metadata.ts`** file in this package (see `config/README.txt`). The proposal LLM reads a short excerpt so test steps can reference realistic labels and flows from your Salesforce project.

---

## 7. Output folders

Generated files live under:

`tests/jira-proposals/<STORY_KEY>/`

| File | Description |
|------|-------------|
| `proposal.json` | Draft proposals + acceptance criteria text |
| `Test Proposals ~ <STORY_KEY>.html` | Local review page (select rows, edit, submit in pipeline) |
| `selection.json` | Created when you submit from the pipeline review server |
| `created-manifest.json` | Written by push: maps proposal `id` → JIRA issue key |
| `context-from-jira.json` | Written by generate; optional context from `fetch-jira-proposal-context` |

---

## 8. Security notes

- Never commit **`.env`** to git; keep tokens private.
- API tokens inherit the permissions of the JIRA user; use a bot or dedicated QA account if policy requires it.
