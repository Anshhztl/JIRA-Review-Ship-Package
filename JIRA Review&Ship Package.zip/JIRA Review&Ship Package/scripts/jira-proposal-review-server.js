/**
 * Local HTTP server for pipeline review: serves editable review UI, POST /submit
 * writes selection.json + proposal.json then exits (batch file continues with push).
 *
 * Usage: node scripts/jira-proposal-review-server.js <STORY_KEY>
 */

const http = require('http');
const path = require('path');
const fs = require('fs');

const { buildReviewHtml } = require('./lib/proposal-review-html');
const { reviewHtmlFileName } = require('./lib/jira-proposal-review-filename');
const projectRoot = path.resolve(__dirname, '..');

function readProposal(storyKey) {
  const p = path.join(projectRoot, 'tests', 'jira-proposals', storyKey, 'proposal.json');
  if (!fs.existsSync(p)) throw new Error(`Missing proposal: ${p}`);
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function rebuildStaticReview(storyKey, data) {
  const html = buildReviewHtml(data, { pipeline: false });
  const name = reviewHtmlFileName(storyKey);
  const out = path.join(projectRoot, 'tests', 'jira-proposals', storyKey, name);
  const legacy = path.join(projectRoot, 'tests', 'jira-proposals', storyKey, 'review.html');
  if (fs.existsSync(legacy) && path.resolve(legacy) !== path.resolve(out)) {
    try {
      fs.unlinkSync(legacy);
    } catch (_) {}
  }
  fs.writeFileSync(out, html, 'utf8');
}

function main() {
  const storyKey = process.argv[2];
  if (!storyKey) {
    console.error('Usage: node scripts/jira-proposal-review-server.js <STORY_KEY>');
    process.exit(1);
  }

  const storyDir = path.join(projectRoot, 'tests', 'jira-proposals', storyKey);

  const server = http.createServer((req, res) => {
    if (req.method === 'GET' && (req.url === '/' || req.url.startsWith('/?'))) {
      try {
        const data = readProposal(storyKey);
        const html = buildReviewHtml(data, { pipeline: true });
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(html);
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(String(e.message || e));
      }
      return;
    }

    if (req.method === 'POST' && req.url === '/submit') {
      let body = '';
      req.on('data', (c) => {
        body += c;
        if (body.length > 8 * 1024 * 1024) req.destroy();
      });
      req.on('end', () => {
        try {
          const j = JSON.parse(body);
          if (j.storyKey !== storyKey) {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('storyKey mismatch');
            return;
          }
          if (!Array.isArray(j.selectedIds) || !j.selectedIds.length) {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('selectedIds required');
            return;
          }
          if (!j.proposal || !Array.isArray(j.proposal.proposals)) {
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('proposal object required');
            return;
          }

          fs.writeFileSync(
            path.join(storyDir, 'selection.json'),
            JSON.stringify({ storyKey, selectedIds: j.selectedIds }, null, 2),
            'utf8'
          );
          fs.writeFileSync(path.join(storyDir, 'proposal.json'), JSON.stringify(j.proposal, null, 2), 'utf8');
          rebuildStaticReview(storyKey, j.proposal);

          res.writeHead(200, { 'Content-Type': 'text/plain' });
          res.end('OK');
          setImmediate(() => {
            server.close(() => process.exit(0));
          });
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end(String(e.message || e));
        }
      });
      return;
    }

    res.writeHead(404);
    res.end();
  });

  server.listen(0, '127.0.0.1', () => {
    const port = server.address().port;
    const url = `http://127.0.0.1:${port}/`;
    process.stdout.write(`JIRA_PROPOSAL_REVIEW_URL=${url}\n`);
    console.log('Review server listening. Open the URL above in Chrome, then submit when ready.');

    const { exec } = require('child_process');
    const chromeCandidates = [
      process.env.CHROME_PATH,
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    ].filter(Boolean);

    let launched = false;
    for (const exe of chromeCandidates) {
      if (fs.existsSync(exe)) {
        exec(`"${exe}" "${url}"`, { windowsHide: true });
        launched = true;
        break;
      }
    }
    if (!launched) {
      exec(`start "" "${url}"`, { shell: true, windowsHide: true });
    }
  });
}

main();
