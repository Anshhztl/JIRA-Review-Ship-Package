/**
 * JIRA REST API helpers for the QA automation flow.
 */

const fs = require('fs');
const path = require('path');
const { loadEnv } = require('../lib/env');

function getClient() {
  const env = loadEnv();
  const baseUrl = (env.JIRA_BASE_URL || '').replace(/\/$/, '');
  const email = env.JIRA_EMAIL || '';
  const token = env.JIRA_API_TOKEN || '';
  if (!baseUrl || !email || !token) throw new Error('Missing JIRA_BASE_URL, JIRA_EMAIL, or JIRA_API_TOKEN in .env');
  const auth = Buffer.from(`${email}:${token}`).toString('base64');
  return {
    baseUrl,
    env,
    async get(pathname) {
      const res = await fetch(`${baseUrl}${pathname}`, {
        headers: { Accept: 'application/json', Authorization: `Basic ${auth}` },
      });
      if (!res.ok) {
        const text = await res.text();
        let body;
        try { body = JSON.parse(text); } catch { body = { message: text }; }
        const err = new Error(body.errorMessages?.join('\n') || body.message || `${res.status} ${res.statusText}`);
        err.status = res.status;
        err.body = body;
        throw err;
      }
      return res.json();
    },
    async post(pathname, body) {
      const res = await fetch(`${baseUrl}${pathname}`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Basic ${auth}`,
        },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const text = await res.text();
        let errBody;
        try { errBody = JSON.parse(text); } catch { errBody = { message: text }; }
        const msg = errBody.errorMessages?.join('\n') || errBody.errors ? JSON.stringify(errBody.errors) : errBody.message || text;
        const err = new Error(msg || `${res.status} ${res.statusText}`);
        err.status = res.status;
        err.body = errBody;
        throw err;
      }
      const text = await res.text();
      if (!text || !String(text).trim()) return {};
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    },
    async postMultipart(pathname, formData) {
      const res = await fetch(`${baseUrl}${pathname}`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          Authorization: `Basic ${auth}`,
          'X-Atlassian-Token': 'no-check',
        },
        body: formData,
      });
      if (!res.ok) {
        const text = await res.text();
        let errBody;
        try { errBody = JSON.parse(text); } catch { errBody = { message: text }; }
        const err = new Error(errBody.errorMessages?.join('\n') || errBody.message || `${res.status} ${res.statusText}`);
        err.status = res.status;
        err.body = errBody;
        throw err;
      }
      const text = await res.text();
      if (!text || !String(text).trim()) return {};
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    },
    async put(pathname, body) {
      const res = await fetch(`${baseUrl}${pathname}`, {
        method: 'PUT',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Basic ${auth}`,
        },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const text = await res.text();
        let errBody;
        try {
          errBody = JSON.parse(text);
        } catch {
          errBody = { message: text };
        }
        const msg =
          errBody.errorMessages?.join('\n') ||
          (errBody.errors ? JSON.stringify(errBody.errors) : null) ||
          errBody.message ||
          text;
        const err = new Error(msg || `${res.status} ${res.statusText}`);
        err.status = res.status;
        err.body = errBody;
        throw err;
      }
      if (res.status === 204) return {};
      const t = await res.text();
      if (!t) return {};
      try {
        return JSON.parse(t);
      } catch {
        return {};
      }
    },
    async delete(pathname) {
      const res = await fetch(`${baseUrl}${pathname}`, {
        method: 'DELETE',
        headers: { Accept: 'application/json', Authorization: `Basic ${auth}` },
      });
      if (!res.ok) {
        const text = await res.text();
        let errBody;
        try {
          errBody = JSON.parse(text);
        } catch {
          errBody = { message: text };
        }
        const err = new Error(errBody.errorMessages?.join('\n') || errBody.message || `${res.status} ${res.statusText}`);
        err.status = res.status;
        err.body = errBody;
        throw err;
      }
      return {};
    },
  };
}

async function fetchStory(client, storyId) {
  const issue = await client.get(`/rest/api/3/issue/${encodeURIComponent(storyId)}?fields=summary,issuetype,project,issuelinks`);
  const typeName = issue.fields?.issuetype?.name || '';
  if (!/story|epic/i.test(typeName)) {
    console.warn(`Warning: ${storyId} has issue type "${typeName}", not Story. Continuing anyway.`);
  }
  return {
    key: issue.key,
    summary: issue.fields?.summary || '',
    projectKey: issue.fields?.project?.key,
    issuelinks: issue.fields?.issuelinks || [],
  };
}

const DEFAULT_TEST_ISSUE_TYPES = ['Test', 'Test Case', 'Manual Test'];

/**
 * Extract plain text from JIRA ADF (Atlassian Document Format) body.
 */
function adfToPlainText(node) {
  if (!node) return '';
  if (typeof node === 'string') return node;
  if (node.text) return node.text;
  if (node.content && Array.isArray(node.content)) {
    return node.content.map(adfToPlainText).join('');
  }
  return '';
}

/**
 * Fetch test cases from the story's comments. Each comment is treated as one test case:
 * - key: synthetic e.g. {storyKey}-C{index}
 * - summary: first line of comment body (or full body if single line)
 * - parentKey: story key (execution subtask will be created under the story)
 */
async function fetchTestCasesFromComments(client, storyKey) {
  const res = await client.get(`/rest/api/3/issue/${encodeURIComponent(storyKey)}/comment`);
  const comments = res.comments || [];
  const testCases = [];
  comments.forEach((c, i) => {
    const raw = c.body;
    const text = typeof raw === 'string' ? raw : adfToPlainText(raw);
    const trimmed = (text || '').trim();
    if (!trimmed) return;
    let summary = trimmed.split(/\r?\n/)[0].trim();
    const titleMatch = trimmed.match(/\bTitle:\s*([^\n]+?)(?=\s*(?:Preconditions|Steps|$))/i);
    if (titleMatch) summary = titleMatch[1].trim();
    else {
      const firstLine = summary;
      if (/^(Preconditions|Steps|Expected|Test case type|Test flow)\b/i.test(firstLine)) {
        summary = `${storyKey} comment ${i + 1}`;
      }
    }
    if (!summary) summary = trimmed.slice(0, 100);
    testCases.push({
      key: `${storyKey}-C${i + 1}`,
      summary: summary.slice(0, 255),
      description: trimmed,
      /** No real Test Case issue — Test Result sub-task goes under the Story */
      parentKey: storyKey,
      storyKey,
      source: 'comment',
    });
  });
  return testCases;
}

function issueDescriptionAsText(descriptionField) {
  if (!descriptionField) return '';
  if (typeof descriptionField === 'string') return descriptionField;
  return adfToPlainText(descriptionField);
}

/** JIRA Cloud: use GET /rest/api/3/search/jql (legacy GET /search removed — CHANGE-2046). */
async function searchIssuesByJql(client, jql, maxResultsOrFields = 100) {
  let maxResults = 100;
  let fields = 'summary,issuetype,description';
  if (typeof maxResultsOrFields === 'number') {
    maxResults = maxResultsOrFields;
  } else if (typeof maxResultsOrFields === 'string') {
    fields = maxResultsOrFields;
    maxResults = 50;
  } else if (maxResultsOrFields && typeof maxResultsOrFields === 'object') {
    maxResults = maxResultsOrFields.maxResults ?? 100;
    if (maxResultsOrFields.fields) fields = maxResultsOrFields.fields;
  }
  const params = new URLSearchParams({
    jql,
    maxResults: String(maxResults),
    fields,
  });
  const data = await client.get(`/rest/api/3/search/jql?${params.toString()}`);
  return data.issues || data.values || [];
}

const subtaskTypeNamesByProject = new Map();
/** @type {Map<string, Array<{ id?: string, name: string }>>} */
const subtaskTypesForCreateByProject = new Map();

/**
 * Sub-task issue types for this project: { id?, name } (prefer id when creating issues).
 * Tries /issuetype/project/ first, then /issue/createmeta (works on many Jira Cloud sites where the former returns HTML/404).
 */
async function getProjectSubtaskTypesForCreate(client, projectIdOrKey) {
  const k = String(projectIdOrKey);
  if (subtaskTypesForCreateByProject.has(k)) return subtaskTypesForCreateByProject.get(k);

  const list = [];

  try {
    const data = await client.get(`/rest/api/3/issuetype/project/${encodeURIComponent(k)}`);
    const arr = Array.isArray(data) ? data : [];
    for (const t of arr) {
      if (t && t.subtask && t.name) {
        list.push({ id: t.id != null ? String(t.id) : undefined, name: String(t.name) });
      }
    }
  } catch (e) {
    const msg = String(e.message || '');
    const short = msg.length > 120 ? `${msg.slice(0, 120)}…` : msg;
    console.warn('  issuetype/project not usable for project', k + ':', short);
  }

  if (!list.length) {
    try {
      const params = new URLSearchParams({ projectKeys: k });
      const meta = await client.get(`/rest/api/3/issue/createmeta?${params.toString()}`);
      const project = (meta.projects || [])[0];
      for (const t of project?.issuetypes || []) {
        if (t.subtask && t.name) {
          list.push({ id: t.id != null ? String(t.id) : undefined, name: String(t.name) });
        }
      }
      if (list.length) {
        console.log('  Sub-task types from createmeta:', list.map((x) => x.name).join(', '));
      }
    } catch (e2) {
      const msg = String(e2.message || '');
      console.warn('  createmeta failed for sub-task types:', msg.length > 120 ? `${msg.slice(0, 120)}…` : msg);
    }
  }

  subtaskTypesForCreateByProject.set(k, list);
  subtaskTypeNamesByProject.set(
    k,
    list.map((x) => x.name)
  );
  return list;
}

/**
 * Sub-task issue type names allowed in this project (from JIRA).
 */
async function getProjectSubtaskTypeNames(client, projectIdOrKey) {
  const types = await getProjectSubtaskTypesForCreate(client, projectIdOrKey);
  return types.map((t) => t.name);
}

/**
 * Test issues whose parent is the Story (common on JIRA boards).
 */
async function fetchChildTestCases(client, storyKey, testIssueTypes = DEFAULT_TEST_ISSUE_TYPES) {
  const typeList = testIssueTypes.map((t) => `"${String(t).replace(/"/g, '')}"`).join(', ');
  const jqlVariants = [
    `parent = ${storyKey} AND issuetype in (${typeList})`,
    `issue in childIssuesOf(${storyKey}) AND issuetype in (${typeList})`,
    `parent = ${storyKey}`,
  ];

  const mapIssue = (issue) => {
    const descText = issueDescriptionAsText(issue.fields?.description);
    const summary = (issue.fields?.summary || '').trim() || issue.key;
    return {
      key: issue.key,
      summary: summary.slice(0, 255),
      description: descText,
      parentKey: issue.key,
      storyKey,
      source: 'child',
    };
  };

  for (const jql of jqlVariants) {
    try {
      const issues = await searchIssuesByJql(client, jql, 100);
      const filtered = issues.filter((issue) => {
        const typeName = (issue.fields?.issuetype?.name || '').trim();
        return testIssueTypes.some((t) => t.toLowerCase() === typeName.toLowerCase());
      });
      if (!filtered.length) continue;
      return filtered.map(mapIssue);
    } catch (e) {
      const detail = e.body ? JSON.stringify(e.body) : '';
      console.warn('  Child test JQL failed:', jql.slice(0, 90), '|', e.message, detail);
    }
  }
  return [];
}

async function fetchLinkedTestCases(client, storyKey, testIssueTypes = DEFAULT_TEST_ISSUE_TYPES) {
  const issue = await client.get(
    `/rest/api/3/issue/${encodeURIComponent(storyKey)}?fields=issuelinks`
  );
  const links = issue.fields?.issuelinks || [];
  const candidateKeys = new Set();
  for (const link of links) {
    const other = link.outwardIssue || link.inwardIssue;
    if (other?.key) candidateKeys.add(other.key);
  }
  const testCases = [];
  for (const key of candidateKeys) {
    try {
      const full = await client.get(`/rest/api/3/issue/${encodeURIComponent(key)}?fields=summary,issuetype,description`);
      const typeName = (full.fields?.issuetype?.name || '').trim();
      if (!testIssueTypes.some((t) => t.toLowerCase() === typeName.toLowerCase())) continue;
      const descText = issueDescriptionAsText(full.fields?.description);
      testCases.push({
        key: full.key,
        summary: (full.fields?.summary || '').trim() || full.key,
        description: descText,
        /** Test Result sub-task parent = this Test Case issue */
        parentKey: full.key,
        storyKey,
        source: 'linked',
      });
    } catch (e) {
      console.warn('  Could not fetch linked issue', key, ':', e.message);
    }
  }
  return testCases;
}

/** Max ADF text node length (Jira limit per text node). */
const ADF_TEXT_CHUNK = 32000;

function chunkStringForAdf(text) {
  const t = String(text || '');
  const parts = [];
  for (let i = 0; i < t.length; i += ADF_TEXT_CHUNK) {
    parts.push(t.slice(i, i + ADF_TEXT_CHUNK));
  }
  return parts.length ? parts : [''];
}

/**
 * Plain text → Atlassian Document Format. Splits on blank lines; long paragraphs are chunked so nothing is silently truncated.
 */
function adfFromPlainText(longText) {
  const raw = (longText || '').trim();
  if (!raw) return undefined;
  const paragraphs = raw.split(/\n\n+/).map((p) => p.trim()).filter(Boolean);
  const content = [];
  for (const para of paragraphs) {
    for (const chunk of chunkStringForAdf(para)) {
      content.push({
        type: 'paragraph',
        content: [{ type: 'text', text: chunk }],
      });
    }
  }
  if (!content.length) return undefined;
  return { type: 'doc', version: 1, content };
}

/**
 * Split plain-text proposal body into description vs "Expected Results" block (for a dedicated Jira field).
 */
function splitExpectedFromDescription(descriptionPlain) {
  const raw = String(descriptionPlain || '').trim();
  if (!raw) return { body: '', expected: '' };
  const re =
    /(?:^|\n)\s*(?:#{1,3}\s*)?(?:\*\*)?\s*Expected Results(?:\*\*)?\s*:?\s*(?:\n|$)/i;
  const m = raw.match(re);
  if (!m || m.index == null) return { body: raw, expected: '' };
  const body = raw.slice(0, m.index).trimEnd();
  const expected = raw.slice(m.index + m[0].length).trim();
  return { body: body || raw, expected };
}

/**
 * Test-case description body → ADF with section headings (Title / Preconditions / Steps / …).
 */
function adfStructuredTestCaseBody(bodyPlain) {
  const raw = String(bodyPlain || '').trim();
  if (!raw) return undefined;
  const lines = raw.split(/\r?\n/);
  const content = [];
  let paraBuf = [];

  function flushPara() {
    if (!paraBuf.length) return;
    const text = paraBuf.join('\n').trim();
    if (!text) {
      paraBuf = [];
      return;
    }
    for (const chunk of chunkStringForAdf(text)) {
      content.push({
        type: 'paragraph',
        content: [{ type: 'text', text: chunk }],
      });
    }
    paraBuf = [];
  }

  const headingRe = /^(Title|Preconditions|Steps|Test data|Notes|Test case type|Test flow)\s*:\s*(.*)$/i;
  for (const line of lines) {
    const hm = line.match(headingRe);
    if (hm) {
      flushPara();
      const label = hm[1].trim();
      const rest = (hm[2] || '').trim();
      content.push({
        type: 'heading',
        attrs: { level: 3 },
        content: [{ type: 'text', text: `${label}` }],
      });
      if (rest) {
        for (const chunk of chunkStringForAdf(rest)) {
          content.push({
            type: 'paragraph',
            content: [{ type: 'text', text: chunk }],
          });
        }
      }
    } else {
      paraBuf.push(line);
    }
  }
  flushPara();
  if (!content.length) return adfFromPlainText(raw);
  return { type: 'doc', version: 1, content };
}

/** Cached Story ↔ Test Case link type from GET /issueLinkType (resolved once per process). */
let storyTestLinkSpecCache = null;

function linksConnectKeys(link, keyA, keyB) {
  const a = link.inwardIssue?.key;
  const b = link.outwardIssue?.key;
  return (a === keyA && b === keyB) || (a === keyB && b === keyA);
}

function issueLinkMatchesSpec(issuelinks, testKey, storyKey, spec) {
  for (const link of issuelinks || []) {
    if (!linksConnectKeys(link, testKey, storyKey)) continue;
    if (spec.id && link.type?.id === spec.id) return true;
    if (!spec.id && spec.name && String(link.type?.name || '').toLowerCase() === String(spec.name).toLowerCase()) {
      return true;
    }
  }
  return false;
}

/**
 * Resolve Jira issue link type for "Test Cases on User Story" (prefers API id).
 * Env JIRA_STORY_TC_LINK_TYPE: exact type name override when auto-match is wrong.
 */
async function getStoryTestCaseLinkSpec(client) {
  if (storyTestLinkSpecCache) return storyTestLinkSpecCache;
  const configured = (process.env.JIRA_STORY_TC_LINK_TYPE || '').trim();
  let picked;
  try {
    const data = await client.get('/rest/api/3/issueLinkType');
    const types = data.issueLinkTypes || [];
    if (configured) {
      picked = types.find((t) => String(t.name || '').toLowerCase() === configured.toLowerCase());
    }
    if (!picked) {
      picked = types.find(
        (t) =>
          /test cases on user story/i.test(String(t.outward || '')) ||
          /test cases on user story/i.test(String(t.inward || '')) ||
          /test cases on user story/i.test(String(t.name || ''))
      );
    }
    if (!picked) {
      picked = types.find((t) => String(t.name || '').toLowerCase() === 'story-tc');
    }
    storyTestLinkSpecCache = picked
      ? { id: picked.id, name: picked.name, inward: picked.inward, outward: picked.outward }
      : { name: configured || 'Story-TC' };
  } catch (e) {
    console.warn('  Could not load issue link types, using name only:', e.message || e);
    storyTestLinkSpecCache = { name: configured || 'Story-TC' };
  }
  return storyTestLinkSpecCache;
}

function orderInwardOutwardForStoryTest(spec, testKey, storyKey) {
  const inwardLabel = String(spec.inward || '').toLowerCase();
  if (inwardLabel.includes('test case')) {
    return { inward: testKey, outward: storyKey };
  }
  if (inwardLabel.includes('user story') || (inwardLabel.includes('story') && !inwardLabel.includes('test'))) {
    return { inward: storyKey, outward: testKey };
  }
  return { inward: testKey, outward: storyKey };
}

async function issueLinkCreate(client, inwardKey, outwardKey, spec) {
  const type = spec?.id ? { id: spec.id } : { name: spec.name || 'Story-TC' };
  await client.post('/rest/api/3/issueLink', {
    type,
    inwardIssue: { key: inwardKey },
    outwardIssue: { key: outwardKey },
  });
}

/**
 * One Story–Test Case link using the correct inward/outward for your Jira link type. Idempotent.
 */
async function ensureStoryTcLink(client, testKey, storyKey) {
  if ((process.env.JIRA_STORY_TC_AFTER_CREATE || 'always').trim().toLowerCase() === 'never') return;

  const spec = await getStoryTestCaseLinkSpec(client);
  const issue = await client.get(
    `/rest/api/3/issue/${encodeURIComponent(testKey)}?fields=issuelinks`
  );
  const links = issue.fields?.issuelinks || [];
  if (issueLinkMatchesSpec(links, testKey, storyKey, spec)) return;

  const primary = orderInwardOutwardForStoryTest(spec, testKey, storyKey);
  try {
    await issueLinkCreate(client, primary.inward, primary.outward, spec);
    return;
  } catch (e1) {
    const issue2 = await client.get(
      `/rest/api/3/issue/${encodeURIComponent(testKey)}?fields=issuelinks`
    );
    if (issueLinkMatchesSpec(issue2.fields?.issuelinks, testKey, storyKey, spec)) return;
    const alt = { inward: primary.outward, outward: primary.inward };
    try {
      await issueLinkCreate(client, alt.inward, alt.outward, spec);
    } catch (e2) {
      console.warn(
        `  Could not add Story–Test link (${spec.name || spec.id}) ${testKey} ↔ ${storyKey}:`,
        e1.message || e1
      );
    }
  }
}

/** Remove "Relates" links between two issues (optional cleanup after automation). */
async function removeRelatesBetween(client, keyA, keyB) {
  for (const anchor of [keyA, keyB]) {
    let issue;
    try {
      issue = await client.get(`/rest/api/3/issue/${encodeURIComponent(anchor)}?fields=issuelinks`);
    } catch {
      continue;
    }
    for (const link of issue.fields?.issuelinks || []) {
      if (String(link.type?.name || '').toLowerCase() !== 'relates') continue;
      if (!linksConnectKeys(link, keyA, keyB)) continue;
      const lid = link.id;
      if (lid == null) continue;
      try {
        await client.delete(`/rest/api/3/issueLink/${encodeURIComponent(String(lid))}`);
      } catch (e) {
        if (e.status === 404) continue;
        console.warn(`  Could not remove Relates link ${lid}:`, e.message || e);
      }
    }
  }
}

async function resolveDefaultAssigneeAccountId(client) {
  const direct = (client.env.JIRA_ASSIGNEE_ACCOUNT_ID || '').trim();
  if (direct) return direct;
  const email = (client.env.JIRA_EMAIL || '').trim();
  if (!email) return null;
  const data = await client.get(`/rest/api/3/user/search?query=${encodeURIComponent(email)}&maxResults=10`);
  const arr = Array.isArray(data) ? data : data.users || [];
  const hit = arr.find((u) => (u.emailAddress || '').toLowerCase() === email.toLowerCase()) || arr[0];
  return hit?.accountId || null;
}

function buildExecutionDescription({ status, durationMs, error, storyKey, testCaseKey, testTitle }) {
  const lines = [
    `Status: ${status}`,
    `User story: ${storyKey}`,
    `Test case: ${testCaseKey}`,
    testTitle ? `Test title: ${testTitle.slice(0, 500)}` : '',
    durationMs ? `Duration: ${Math.round(durationMs / 1000)}s` : '',
    error ? `Error / stack (truncated):\n${error.slice(0, 4000)}` : '',
    '',
    'Screenshot and/or video recording (if enabled) are attached to this execution task.',
    '',
    'Full test case text (preconditions, steps, expected results from JIRA) is stored in the Environment field.',
  ].filter(Boolean);
  return lines.join('\n\n');
}

function buildBugDescription({ storyKey, storySummary, testCaseKey, testTitle, error, stack }) {
  const when = new Date().toISOString();
  const lines = [
    'Automated Playwright test failure (Salesforce sandbox QA run)',
    '',
    `Reported: ${when}`,
    `User story: ${storyKey}${storySummary ? ` — ${storySummary.slice(0, 200)}` : ''}`,
    `Failed test case: ${testCaseKey}`,
    testTitle ? `Playwright test title: ${testTitle.slice(0, 500)}` : '',
    '',
    'What happened:',
    (error || stack)
      ? `${(error || '') + (stack ? '\n' + stack : '')}`.slice(0, 8000)
      : '(No error text captured — check attached video/screenshot.)',
    '',
    'Evidence:',
    '- Screenshot(s) and/or screen recording should be attached to this issue (see attachments).',
    '- If missing, re-run with: npm run jira:execute:interactive -- <STORY_ID>',
    '',
    'Next steps:',
    '- Review attachments (video preferred for repro).',
    '- Fix app or update the Playwright spec using codegen, then re-run.',
  ].filter(Boolean);
  return lines.join('\n');
}

async function createSubtask(client, parentKey, summary, description = '', options = {}) {
  const assigneeAccountId = (options.assigneeAccountId || '').trim() || null;
  const projKey = (await client.get(`/rest/api/3/issue/${encodeURIComponent(parentKey)}?fields=project`)).fields.project.key;
  const descField = description
    ? adfFromPlainText(description) || {
        type: 'doc',
        version: 1,
        content: [{ type: 'paragraph', content: [{ type: 'text', text: description.slice(0, 32000) }] }],
      }
    : undefined;

  const fromEnv = (process.env.JIRA_SUBTASK_ISSUE_TYPE || '').trim();
  const typeNames = fromEnv ? [fromEnv] : ['Sub-task', 'Subtask'];

  let lastErr;
  for (const typeName of typeNames) {
    const body = {
      fields: {
        project: { key: projKey },
        parent: { key: parentKey },
        summary: (summary || '').slice(0, 255),
        issuetype: { name: typeName },
      },
    };
    if (descField) body.fields.description = descField;
    if (assigneeAccountId) body.fields.assignee = { accountId: assigneeAccountId };
    try {
      const created = await client.post('/rest/api/3/issue', body);
      return created.key;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr;
}

/** Plain-text cap before we add a truncation notice (Environment field). */
const TEST_RESULT_ENV_MAX_PLAIN = 120000;

/**
 * Sub-task under a Test Case (or Story for comment-only cases) — type "Test Result" when your project has it.
 * Env: JIRA_TEST_RESULT_ISSUE_TYPE (exact name). Otherwise tries common names, then Sub-task.
 * Env: JIRA_TEST_RESULT_ENVIRONMENT_FIELD — custom field id (e.g. customfield_10048); default field id is "environment".
 * Full test-case description (preconditions/steps from JIRA) is written to the Environment field as ADF.
 */
function scoreSubtaskTypeName(name) {
  const n = String(name || '').toLowerCase();
  if (n.includes('test result')) return 0;
  if (n.includes('test execution')) return 1;
  if (n.includes('sub-task') || n.includes('subtask')) return 2;
  return 3;
}

/**
 * Build ordered list of issuetype payloads to try (id is more reliable than name on some sites).
 */
function buildTestResultIssuetypeAttempts(fromEnv, projectSubtasks) {
  /** @type {Array<{ name?: string, id?: string }>} */
  const attempts = [];
  const seen = new Set();

  function add(payload) {
    const key = payload.id ? `id:${payload.id}` : `name:${(payload.name || '').toLowerCase()}`;
    if (seen.has(key)) return;
    seen.add(key);
    attempts.push(payload);
  }

  const sorted = [...projectSubtasks].sort(
    (a, b) => scoreSubtaskTypeName(a.name) - scoreSubtaskTypeName(b.name)
  );

  if (fromEnv) {
    const match = sorted.find((t) => t.name.toLowerCase() === fromEnv.toLowerCase());
    if (match?.id) add({ id: match.id });
    add({ name: fromEnv });
  }

  for (const t of sorted) {
    if (t.id) add({ id: t.id });
    add({ name: t.name });
  }

  const fallbacks = ['Test Result', 'Test result', 'Test Execution', 'Test execution', 'Sub-task', 'Subtask'];
  for (const name of fallbacks) add({ name });

  return attempts;
}

async function createTestResultSubtask(client, parentKey, summary, description = '', environmentPlain = '') {
  /** Always use the parent issue's project (do not use JIRA_PROJECT_KEY — it may not match TPQA vs QAP). */
  const projKey = (await client.get(`/rest/api/3/issue/${encodeURIComponent(parentKey)}?fields=project`)).fields.project.key;
  const descField = description
    ? adfFromPlainText(description) || {
        type: 'doc',
        version: 1,
        content: [{ type: 'paragraph', content: [{ type: 'text', text: description.slice(0, 32000) }] }],
      }
    : undefined;

  const envRaw = (environmentPlain || '').trim();
  const envPlainForJira =
    envRaw.length > TEST_RESULT_ENV_MAX_PLAIN
      ? `${envRaw.slice(0, TEST_RESULT_ENV_MAX_PLAIN)}\n\n[Truncated — test case description exceeded ${TEST_RESULT_ENV_MAX_PLAIN} characters.]`
      : envRaw;
  const envAdf = envPlainForJira ? adfFromPlainText(envPlainForJira) : undefined;
  const envFieldKey = (process.env.JIRA_TEST_RESULT_ENVIRONMENT_FIELD || 'environment').trim();

  const fromEnv = (process.env.JIRA_TEST_RESULT_ISSUE_TYPE || '').trim();
  const projectSubtasks = await getProjectSubtaskTypesForCreate(client, projKey);
  const issuetypeAttempts = fromEnv
    ? buildTestResultIssuetypeAttempts(fromEnv, projectSubtasks)
    : buildTestResultIssuetypeAttempts('', projectSubtasks);

  let lastErr;
  for (const it of issuetypeAttempts) {
    const issuetype = it.id ? { id: it.id } : { name: it.name };
    const bodyBase = {
      fields: {
        project: { key: projKey },
        parent: { key: parentKey },
        summary: (summary || '').slice(0, 255),
        issuetype,
      },
    };
    if (descField) bodyBase.fields.description = descField;

    /** Try with Environment first; if the field is missing on this issue type, retry without it. */
    const payloads = [];
    if (envAdf && envFieldKey) {
      payloads.push({
        fields: { ...bodyBase.fields, [envFieldKey]: envAdf },
      });
    }
    payloads.push(bodyBase);

    for (let pi = 0; pi < payloads.length; pi++) {
      const body = payloads[pi];
      try {
        const created = await client.post('/rest/api/3/issue', body);
        const label = it.id ? `id=${it.id}` : it.name;
        if (
          envAdf &&
          envFieldKey &&
          payloads.length > 1 &&
          pi === payloads.length - 1 &&
          !Object.prototype.hasOwnProperty.call(body.fields, envFieldKey)
        ) {
          console.warn('  Note: Test Result created without Environment (field missing or rejected by Jira).');
        }
        return { key: created.key, issueTypeUsed: label };
      } catch (e) {
        lastErr = e;
      }
    }
  }
  throw lastErr;
}

async function addAttachments(client, issueKey, filePaths) {
  const results = [];
  for (const p of filePaths) {
    const fullPath = path.isAbsolute(p) ? p : path.resolve(process.cwd(), p);
    if (!fs.existsSync(fullPath)) continue;
    const name = path.basename(fullPath);
    const buf = fs.readFileSync(fullPath);
    const form = new FormData();
    form.append('file', new Blob([buf], { type: 'application/octet-stream' }), name);
    const list = await client.postMultipart(`/rest/api/3/issue/${issueKey}/attachments`, form);
    results.push(...(Array.isArray(list) ? list : [list]));
  }
  return results;
}

async function getTransitions(client, issueKey) {
  const data = await client.get(`/rest/api/3/issue/${issueKey}?fields=status`);
  const transitions = await client.get(`/rest/api/3/issue/${issueKey}/transitions`);
  return transitions.transitions || [];
}

async function transition(client, issueKey, transitionNameOrId) {
  const list = await client.get(`/rest/api/3/issue/${issueKey}/transitions`);
  const t = (list.transitions || []).find(
    (tr) => tr.name === transitionNameOrId || String(tr.id) === String(transitionNameOrId)
  );
  if (!t) {
    console.warn(`Transition "${transitionNameOrId}" not found for ${issueKey}. Available: ${(list.transitions || []).map((x) => x.name).join(', ')}`);
    return;
  }
  await client.post(`/rest/api/3/issue/${issueKey}/transitions`, { transition: { id: t.id } });
}

const QA_ARTIFACT_CREATE_SUMMARY_DEFAULT = 'QA Artifact - Test case creation';
const QA_ARTIFACT_EXECUTE_SUMMARY_DEFAULT = 'QA Artifact - Test case execution';

function pickIssueByExactSummary(issues, wantSummary) {
  const w = wantSummary.trim();
  return issues.find((i) => (i.fields?.summary || '').trim() === w);
}

/**
 * Create QA artifact subtasks on the story before test cases (idempotent by exact summary).
 * Assigns to JIRA_ASSIGNEE_ACCOUNT_ID or the user matching JIRA_EMAIL.
 * 1) Test case creation → transition to Done
 * 2) Test case execution → optional transition to To Do
 */
async function setAssigneeOnIssue(client, issueKey, accountId) {
  if (!issueKey || !accountId) return;
  try {
    await client.put(`/rest/api/3/issue/${encodeURIComponent(issueKey)}`, {
      fields: { assignee: { accountId } },
    });
  } catch (e) {
    console.warn(`  Could not set assignee on ${issueKey}:`, e.message || e);
  }
}

async function ensureQaArtifactSubtasks(client, storyKey) {
  const sumCreate = (process.env.JIRA_QA_ARTIFACT_CREATE_SUMMARY || QA_ARTIFACT_CREATE_SUMMARY_DEFAULT).trim();
  const sumExecute = (process.env.JIRA_QA_ARTIFACT_EXECUTE_SUMMARY || QA_ARTIFACT_EXECUTE_SUMMARY_DEFAULT).trim();
  const doneTransition = (process.env.JIRA_QA_ARTIFACT_CREATE_DONE_TRANSITION || 'Done').trim();
  const todoTransition = (process.env.JIRA_QA_ARTIFACT_EXECUTION_TODO_TRANSITION || '').trim();

  const assigneeId = await resolveDefaultAssigneeAccountId(client);
  if (!assigneeId) {
    console.warn(
      '  QA subtasks: set JIRA_ASSIGNEE_ACCOUNT_ID (Atlassian account ID) or JIRA_EMAIL so subtasks can be assigned to you.'
    );
  }

  const jql = `parent = ${storyKey} AND summary ~ "QA Artifact - Test case"`;
  let existing = [];
  try {
    existing = await searchIssuesByJql(client, jql, 'summary,status');
  } catch (e) {
    console.warn('  QA artifact search failed, will try create anyway:', e.message || e);
    existing = [];
  }

  let createKey = pickIssueByExactSummary(existing, sumCreate)?.key;
  if (!createKey) {
    createKey = await createSubtask(client, storyKey, sumCreate, 'QA tracking: test case authoring for this story (automation).', {
      assigneeAccountId: assigneeId,
    });
    console.log('  QA artifact subtask:', createKey, sumCreate);
  }
  await setAssigneeOnIssue(client, createKey, assigneeId);
  await transition(client, createKey, doneTransition);

  let execKey = pickIssueByExactSummary(existing, sumExecute)?.key;
  if (!execKey) {
    execKey = await createSubtask(client, storyKey, sumExecute, 'QA tracking: test case execution for this story (automation).', {
      assigneeAccountId: assigneeId,
    });
    console.log('  QA artifact subtask:', execKey, sumExecute);
  }
  await setAssigneeOnIssue(client, execKey, assigneeId);
  if (todoTransition) {
    await transition(client, execKey, todoTransition);
  }
}

/**
 * Set Test Result workflow from automation outcome (pass vs fail).
 * Env: JIRA_TRANSITION_PASSED (default PASSED), JIRA_TRANSITION_FAILED (default FAILED).
 * Falls back to common names if your workflow uses different labels.
 */
async function transitionTestResultByOutcome(client, issueKey, passed) {
  const primaryPass = (process.env.JIRA_TRANSITION_PASSED || 'PASSED').trim();
  const primaryFail = (process.env.JIRA_TRANSITION_FAILED || 'FAILED').trim();
  const passCandidates = [primaryPass, 'PASSED', 'Passed', 'Done', 'Complete', 'Closed', 'Close', 'Resolve'];
  const failCandidates = [primaryFail, 'FAILED', 'Failed', 'Fail'];
  const candidates = passed ? passCandidates : failCandidates;
  const uniq = [...new Set(candidates.filter(Boolean))];

  const list = await client.get(`/rest/api/3/issue/${encodeURIComponent(issueKey)}/transitions`);
  const transitions = list.transitions || [];

  for (const name of uniq) {
    const t = transitions.find(
      (tr) => tr.name === name || tr.name.toLowerCase() === String(name).toLowerCase()
    );
    if (t) {
      await client.post(`/rest/api/3/issue/${encodeURIComponent(issueKey)}/transitions`, {
        transition: { id: t.id },
      });
      console.log(`  Transition ${issueKey} → ${t.name} (${passed ? 'pass' : 'fail'})`);
      return t.name;
    }
  }

  console.warn(
    `  Could not transition ${issueKey} for ${passed ? 'PASSED' : 'FAILED'}. Tried: ${uniq.join(', ')}. Available: ${transitions.map((x) => x.name).join(', ')}`
  );
  return null;
}

async function createBug(client, parentStoryKey, summary, description) {
  const projKey = (await client.get(`/rest/api/3/issue/${encodeURIComponent(parentStoryKey)}?fields=project`)).fields.project.key;
  const body = {
    fields: {
      project: { key: projKey },
      parent: { key: parentStoryKey },
      summary: (summary || '').slice(0, 255),
      issuetype: { name: 'Bug' },
    },
  };
  if (description) body.fields.description = adfFromPlainText(description) || { type: 'doc', version: 1, content: [{ type: 'paragraph', content: [{ type: 'text', text: description.slice(0, 32000) }] }] };
  const created = await client.post('/rest/api/3/issue', body);
  return created.key;
}

async function createBugAndLinkToStory(client, storyKey, summary, description) {
  const projKey = (await client.get(`/rest/api/3/issue/${encodeURIComponent(storyKey)}?fields=project`)).fields.project.key;
  const body = {
    fields: {
      project: { key: projKey },
      summary: (summary || '').slice(0, 255),
      issuetype: { name: 'Bug' },
    },
  };
  if (description) body.fields.description = adfFromPlainText(description) || { type: 'doc', version: 1, content: [{ type: 'paragraph', content: [{ type: 'text', text: description.slice(0, 32000) }] }] };
  const created = await client.post('/rest/api/3/issue', body);
  try {
    await client.post('/rest/api/3/issueLink', {
      type: { name: 'Relates' },
      inwardIssue: { key: storyKey },
      outwardIssue: { key: created.key },
    });
  } catch (e) {
    try {
      await client.post('/rest/api/3/issueLink', {
        type: { name: 'Relates' },
        inwardIssue: { key: created.key },
        outwardIssue: { key: storyKey },
      });
    } catch (_) {}
  }
  return created.key;
}

async function linkIssues(client, inwardKey, outwardKey, linkTypeName = 'Relates') {
  await client.post('/rest/api/3/issueLink', {
    type: { name: linkTypeName },
    inwardIssue: { key: inwardKey },
    outwardIssue: { key: outwardKey },
  });
}

const createMetaFieldsByProjectAndType = new Map();
let jiraAllFieldsCache = null;

async function loadCreateMetaFields(client, projectKey, issueTypeName) {
  const cacheKey = `${projectKey}\0${issueTypeName}`;
  if (createMetaFieldsByProjectAndType.has(cacheKey)) {
    return createMetaFieldsByProjectAndType.get(cacheKey);
  }
  const params = new URLSearchParams({
    projectKeys: projectKey,
    issuetypeNames: issueTypeName,
    expand: 'projects.issuetypes.fields',
  });
  const meta = await client.get(`/rest/api/3/issue/createmeta?${params.toString()}`);
  const fields = meta?.projects?.[0]?.issuetypes?.[0]?.fields || {};
  createMetaFieldsByProjectAndType.set(cacheKey, fields);
  return fields;
}

/** First issue type in typeNames that returns createmeta fields (for custom-field mapping). */
async function getCreateMetaFieldsForFirstMatchingType(client, projectKey, typeNames) {
  for (const issueTypeName of typeNames) {
    try {
      const fields = await loadCreateMetaFields(client, projectKey, issueTypeName);
      if (fields && Object.keys(fields).length) return { issueTypeName, fields };
    } catch (_) {
      /* try next type name */
    }
  }
  return null;
}

function findFieldIdInCreateMetaFields(fieldsObj, displayName) {
  if (!fieldsObj || !displayName) return '';
  const want = displayName.trim().toLowerCase();
  for (const [fieldId, def] of Object.entries(fieldsObj)) {
    if (String(def?.name || '').trim().toLowerCase() === want) return fieldId;
  }
  return '';
}

async function getAllJiraFieldsCached(client) {
  if (jiraAllFieldsCache) return jiraAllFieldsCache;
  jiraAllFieldsCache = await client.get('/rest/api/3/field');
  return jiraAllFieldsCache;
}

async function findJiraFieldIdByNameFromGlobalList(client, displayName) {
  if (!displayName) return '';
  try {
    const all = await getAllJiraFieldsCached(client);
    if (!Array.isArray(all)) return '';
    const want = displayName.trim().toLowerCase();
    const hit = all.find((f) => String(f?.name || '').trim().toLowerCase() === want);
    return hit?.id ? String(hit.id) : '';
  } catch {
    return '';
  }
}

async function resolveTestCaseFieldIds(client, projectKey, typeNames, fieldsObj) {
  const typeLabel = (process.env.JIRA_TEST_CASE_TYPE_FIELD_LABEL || 'Test case type').trim();
  const flowLabel = (process.env.JIRA_TEST_CASE_FLOW_FIELD_LABEL || 'Flow').trim();
  const expectedLabel = (process.env.JIRA_TEST_CASE_EXPECTED_RESULTS_LABEL || 'Expected Results').trim();

  let typeId = (process.env.JIRA_TEST_CASE_TYPE_FIELD || '').trim();
  let flowId = (process.env.JIRA_TEST_CASE_FLOW_FIELD || '').trim();
  let expectedId = (process.env.JIRA_TEST_CASE_EXPECTED_RESULTS_FIELD || '').trim();

  const fo = fieldsObj || {};
  if (!typeId) typeId = findFieldIdInCreateMetaFields(fo, typeLabel);
  if (!typeId) typeId = findFieldIdInCreateMetaFields(fo, 'Test Case Type');
  if (!flowId) flowId = findFieldIdInCreateMetaFields(fo, flowLabel);
  if (!expectedId) expectedId = findFieldIdInCreateMetaFields(fo, expectedLabel);
  if (!expectedId) expectedId = findFieldIdInCreateMetaFields(fo, 'Expected result');

  if (!typeId) typeId = await findJiraFieldIdByNameFromGlobalList(client, typeLabel);
  if (!typeId) typeId = await findJiraFieldIdByNameFromGlobalList(client, 'Test Case Type');
  if (!flowId) flowId = await findJiraFieldIdByNameFromGlobalList(client, flowLabel);
  if (!expectedId) expectedId = await findJiraFieldIdByNameFromGlobalList(client, expectedLabel);
  if (!expectedId) expectedId = await findJiraFieldIdByNameFromGlobalList(client, 'Expected result');

  return { typeId, flowId, expectedId };
}

function fieldActsAsOption(fieldDef) {
  if (!fieldDef) return false;
  const schema = fieldDef.schema || {};
  const type = schema.type;
  const custom = String(schema.custom || '').toLowerCase();
  if (type === 'option' || (type === 'array' && schema.items === 'option')) return true;
  if (custom.includes('select') || custom.includes('radio') || custom.includes('cascading')) return true;
  return false;
}

function valueForJiraCustomField(fieldDef, rawText) {
  const text = String(rawText ?? '').trim();
  if (!text) return undefined;
  if (!fieldDef) return text;

  const schema = fieldDef.schema || {};
  const type = schema.type;
  const items = schema.items;

  if (fieldActsAsOption(fieldDef) || type === 'option' || (type === 'array' && items === 'option')) {
    const av = fieldDef.allowedValues;
    if (Array.isArray(av) && av.length) {
      const low = text.toLowerCase();
      const hit =
        av.find((o) => String(o.value ?? '').toLowerCase() === low) ||
        av.find((o) => String(o.name ?? '').toLowerCase() === low) ||
        av.find((o) => String(o.value ?? '').toLowerCase().includes(low));
      if (hit) {
        if (hit.id != null) return { id: String(hit.id) };
        if (hit.value != null) return { value: String(hit.value) };
      }
      const segments = low.split(/\s*\/\s*|\s*-\s*/).map((s) => s.trim()).filter((s) => s.length > 1);
      for (const part of [...new Set(segments)].reverse()) {
        const hit2 =
          av.find((o) => String(o.value ?? '').toLowerCase() === part) ||
          av.find((o) => String(o.name ?? '').toLowerCase() === part);
        if (hit2) {
          if (hit2.id != null) return { id: String(hit2.id) };
          if (hit2.value != null) return { value: String(hit2.value) };
        }
      }
      console.warn(
        `  JIRA: no option match for "${fieldDef.name || 'select field'}" = "${text}". Options: ${av
          .slice(0, 12)
          .map((o) => o.value || o.name)
          .join(', ')}${av.length > 12 ? '…' : ''}`
      );
      return undefined;
    }
    console.warn(
      `  JIRA: skipping "${fieldDef.name || 'option field'}" — no allowedValues in create metadata for "${text}".`
    );
    return undefined;
  }

  return text;
}

/** Jira "Expected Results" custom fields usually require ADF, not a plain string. */
function expectedResultsValueForField(fieldDef, expectedText, plainEnv) {
  const exp = String(expectedText || '').trim();
  if (!exp) return undefined;
  const flag = String(plainEnv || '').trim().toLowerCase();
  if (flag === '1' || flag === 'true' || flag === 'yes') return exp.slice(0, 32000);
  return adfFromPlainText(exp) || exp.slice(0, 32000);
}

/**
 * Create a Test / Test Case issue for a story.
 *
 * Default JIRA_TEST_CASE_PARENT_MODE=link_only: issue is created in the story's project without parent,
 * then linked once with the Story–Test Case link type (resolved from /issueLinkType, e.g. "Test Cases on User Story").
 * Set JIRA_TEST_CASE_PARENT_MODE=try_parent to attempt parent=story first (some schemes forbid parent on Test Case).
 *
 * JIRA_TEST_CASE_STRIP_RELATES_TO_STORY (default 1): removes stray Relates links between the new test and the story
 * after the Story–Test link is applied (set to 0 to keep Relates).
 *
 * Maps proposal meta.testCaseType / meta.testFlow to Jira fields named "Test case type" and "Flow" (or
 * JIRA_TEST_CASE_*_FIELD_LABEL overrides). Field ids are resolved from issue create metadata, or set explicitly via
 * JIRA_TEST_CASE_TYPE_FIELD / JIRA_TEST_CASE_FLOW_FIELD / JIRA_TEST_CASE_EXPECTED_RESULTS_FIELD.
 * Text after "Expected Results:" goes to the Jira "Expected Results" field as ADF (required by many setups).
 * Set JIRA_TEST_CASE_EXPECTED_RESULTS_PLAIN=1 only if your field is a plain multi-line string, not ADF.
 */
async function createTestCaseIssue(client, storyKey, summary, descriptionPlain = '', meta = {}) {
  const story = await client.get(`/rest/api/3/issue/${encodeURIComponent(storyKey)}?fields=project`);
  const projKey = story.fields.project.key;
  const fromEnv = (process.env.JIRA_TEST_ISSUE_TYPE || '').trim();
  const typeNames = fromEnv ? [fromEnv] : [...DEFAULT_TEST_ISSUE_TYPES];

  const metaBlock = await getCreateMetaFieldsForFirstMatchingType(client, projKey, typeNames);
  const fieldsObj = metaBlock?.fields || {};
  const { typeId, flowId, expectedId } = await resolveTestCaseFieldIds(client, projKey, typeNames, fieldsObj);

  const typeDef = typeId ? fieldsObj[typeId] : null;
  const flowDef = flowId ? fieldsObj[flowId] : null;
  const expDef = expectedId ? fieldsObj[expectedId] : null;

  const testCaseType = String(meta.testCaseType || '').trim();
  const testFlow = String(meta.testFlow || meta.flowType || '').trim();

  const extraMeta = {};
  if (typeId && testCaseType) {
    const v = valueForJiraCustomField(typeDef, testCaseType);
    if (v !== undefined) extraMeta[typeId] = v;
  }
  if (flowId && testFlow) {
    const v = valueForJiraCustomField(flowDef, testFlow);
    if (v !== undefined) extraMeta[flowId] = v;
  }

  const useStructured = (process.env.JIRA_TEST_CASE_ADF_STRUCTURED || '1').trim() !== '0';
  const plainEnv = process.env.JIRA_TEST_CASE_EXPECTED_RESULTS_PLAIN;

  const { body: bodyAfterSplit, expected } = splitExpectedFromDescription(descriptionPlain);
  const descPlainForIssue = expectedId && expected ? bodyAfterSplit : descriptionPlain;
  const fullDescriptionPlain = descriptionPlain;

  const expectedPayload = {};
  if (expectedId && expected) {
    const ev = expectedResultsValueForField(expDef, expected, plainEnv);
    if (ev !== undefined) expectedPayload[expectedId] = ev;
  }

  const parentMode = (process.env.JIRA_TEST_CASE_PARENT_MODE || 'link_only').trim().toLowerCase();
  const tryParentFirst = parentMode === 'try_parent' || parentMode === 'parent_first';
  const stripRelates = (process.env.JIRA_TEST_CASE_STRIP_RELATES_TO_STORY || '1').trim() !== '0';

  const attempts = [];
  if (tryParentFirst) attempts.push({ useParent: true });
  attempts.push({ useParent: false });

  function makeDesc(plainSource) {
    if (!plainSource) return undefined;
    let d = useStructured ? adfStructuredTestCaseBody(plainSource) : adfFromPlainText(plainSource);
    if (!d) {
      d = {
        type: 'doc',
        version: 1,
        content: [{ type: 'paragraph', content: [{ type: 'text', text: String(plainSource).slice(0, 32000) }] }],
      };
    }
    return d;
  }

  let lastErr;
  for (const { useParent } of attempts) {
    for (const typeName of typeNames) {
      for (const stripCustom of [false, true]) {
        const plainSource = stripCustom ? fullDescriptionPlain : descPlainForIssue;
        const descTry = makeDesc(plainSource);
        const fields = {
          project: { key: projKey },
          summary: (summary || '').slice(0, 255),
          issuetype: { name: typeName },
        };
        if (!stripCustom) Object.assign(fields, expectedPayload, extraMeta);
        if (useParent) fields.parent = { key: storyKey };
        if (descTry) fields.description = descTry;
        const body = { fields };
        try {
          const created = await client.post('/rest/api/3/issue', body);
          if (stripCustom) {
            console.warn(
              '  JIRA: Created test case without mapped custom fields (type / flow / expected). Fix option labels in proposals or JIRA_TEST_CASE_* env — first error:',
              lastErr?.message || lastErr
            );
          }
          await ensureStoryTcLink(client, created.key, storyKey);
          if (stripRelates) await removeRelatesBetween(client, created.key, storyKey);
          return {
            key: created.key,
            issueType: typeName,
            parentStoryKey: storyKey,
            linkedOnly: !useParent,
          };
        } catch (e) {
          lastErr = e;
          const detail = e.body?.errors ? JSON.stringify(e.body.errors) : e.message;
          if (!stripCustom) console.warn('  JIRA create failed:', detail);
        }
      }
    }
  }
  const finalDetail = lastErr?.body?.errors ? JSON.stringify(lastErr.body.errors) : lastErr?.message || String(lastErr);
  throw new Error(finalDetail || 'JIRA issue create failed');
}

/**
 * Update summary and/or description (plain text → ADF) on an existing issue (e.g. when the story changes).
 */
async function updateIssueFields(client, issueKey, { summary, descriptionPlain } = {}) {
  const fields = {};
  if (summary != null) fields.summary = String(summary).slice(0, 255);
  if (descriptionPlain != null) {
    fields.description =
      adfFromPlainText(descriptionPlain) || {
        type: 'doc',
        version: 1,
        content: [{ type: 'paragraph', content: [{ type: 'text', text: String(descriptionPlain).slice(0, 32000) }] }],
      };
  }
  if (!Object.keys(fields).length) return;
  await client.put(`/rest/api/3/issue/${encodeURIComponent(issueKey)}`, { fields });
}

module.exports = {
  getClient,
  fetchStory,
  fetchTestCasesFromComments,
  fetchLinkedTestCases,
  fetchChildTestCases,
  createSubtask,
  createTestResultSubtask,
  addAttachments,
  getTransitions,
  transition,
  transitionTestResultByOutcome,
  createBug,
  createBugAndLinkToStory,
  linkIssues,
  createTestCaseIssue,
  ensureQaArtifactSubtasks,
  updateIssueFields,
  buildExecutionDescription,
  buildBugDescription,
  adfFromPlainText,
  adfToPlainText,
  issueDescriptionAsText,
};
