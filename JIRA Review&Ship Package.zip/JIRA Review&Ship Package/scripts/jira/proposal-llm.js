/**
 * Free / optional paid LLMs for JIRA test proposal generation.
 *
 * Priority (JIRA_PROPOSAL_LLM=auto or unset):
 *   1) Google Gemini — free API key: https://aistudio.google.com/apikey  (GEMINI_API_KEY)
 *   2) Ollama — local, no API cost (OLLAMA_BASE_URL + OLLAMA_MODEL, or JIRA_PROPOSAL_OLLAMA=1)
 *   3) OpenAI — only if OPENAI_API_KEY set and JIRA_PROPOSAL_USE_AI is not 0
 *
 * Force one provider: JIRA_PROPOSAL_LLM=gemini|ollama|openai|none
 */

const fs = require('fs');
const path = require('path');
const {
  getProposalTestCaseTypes,
  getProposalTestFlows,
  canonicalizeTestCaseType,
  canonicalizeTestFlow,
} = require('../lib/jira-proposal-options');

const OPENAI_DEFAULT_URL = 'https://api.openai.com/v1/chat/completions';

function stripJsonFence(text) {
  let t = String(text || '').trim();
  if (t.startsWith('```')) {
    t = t.replace(/^```(?:json)?\s*\n?/i, '');
    t = t.replace(/\n?```\s*$/i, '');
  }
  return t.trim();
}

function readFlowMetadataSnippet(projectRoot, maxLen = 2500) {
  const p = path.join(projectRoot, 'config', 'flow-metadata.ts');
  try {
    if (!fs.existsSync(p)) return '';
    return fs.readFileSync(p, 'utf8').slice(0, maxLen);
  } catch {
    return '';
  }
}

/** Strip legacy lines; type/flow belong in Jira fields only, not in description. */
function cleanProposalDescription(description) {
  let d = String(description || '').trim();
  d = d
    .replace(/^Test case type:\s*.+$/im, '')
    .replace(/^Test flow:\s*.+$/im, '')
    .replace(/^Title:\s*.+$/im, '')
    .replace(/^\n+/, '');
  return d.trim();
}

function normalizeProposals(raw) {
  if (!raw || !Array.isArray(raw.proposals)) return null;
  const types = getProposalTestCaseTypes();
  const flows = getProposalTestFlows();
  const out = [];
  const seen = new Set();
  for (let i = 0; i < raw.proposals.length; i++) {
    const p = raw.proposals[i];
    if (!p || typeof p !== 'object') continue;
    let id = String(p.id || `p${i + 1}`).trim();
    if (seen.has(id)) id = `p${i + 1}`;
    seen.add(id);
    const summary = String(p.summary || '').trim().slice(0, 255);
    let description = String(p.description || '').trim();
    if (!summary && !description) continue;
    const testCaseType = canonicalizeTestCaseType(p.testCaseType, types);
    const testFlow = canonicalizeTestFlow(p.testFlow || p.flowType, flows);
    description = cleanProposalDescription(description);
    out.push({ id, summary: summary || id, description, testCaseType, testFlow });
  }
  return out.length ? out : null;
}

function buildPrompt(ctx, projectRoot) {
  const flowSnippet = readFlowMetadataSnippet(projectRoot);
  const refText = (ctx.references || [])
    .map((r) => `- ${r.key}: ${r.summary || ''} (${r.note || ''})`)
    .join('\n');

  const typeList = getProposalTestCaseTypes();
  const flowList = getProposalTestFlows();
  const typesLine = typeList.join(', ');
  const flowsLine = flowList.join(', ');

  const system = `You are a principal manual QA engineer for Salesforce CRM (Lightning Experience).
You write thorough, realistic manual test cases for JIRA "Test Case" issues used by a team that also automates with Playwright.

CRITICAL — Jira picklist values (use EXACT spelling; no other strings allowed):
- "testCaseType" MUST be exactly one of: ${typesLine}
- "testFlow" MUST be exactly one of: ${flowsLine}

Each test case MUST use this plain-text structure in "description" (do NOT put testCaseType, testFlow, or Title inside description — use JSON fields testCaseType, testFlow, and summary for those):
Preconditions/Test Data:
- <bullet>
Steps:
1. <numbered, actionable — reference App Launcher, object tabs, Save, duplicate alerts, etc. when relevant>
Expected Results:
- <bullet, observable>

Rules:
- Vary testCaseType and testFlow across the set (use different allowed values; include negative and boundary-style cases where the story fits).
- Cover happy path, negative paths, edge cases, and data integrity implied by the story — not only literal AC lines.
- Use concrete Salesforce UX language (Leads tab, New, Edit, Save, Potential Duplicates, etc.) when the story implies those objects.
- Return 6 to 12 proposals unless the story is tiny (then at least 4).
- "summary" is the JIRA issue title (max 255 chars), clear and unique.
- "id" must be stable strings p1, p2, p3, ... in order.

Acceptance criteria (REQUIRED top-level string "acceptanceCriteria"):
- Rewrite the story's acceptance criteria as explicit POINTER lines: one atomic requirement per line, no run-on paragraphs.
- Each line MUST start with a pointer phrase: prefer "When " (capital W) for behaviour, or "Given ", "Then ", "And ", or "Duplicates " when that reads more naturally.
- Do not use markdown bullets (no leading "- "); the line starts with the pointer word.
- Mirror every distinct requirement from the Jira description (including global rules such as matching rules); if the source is vague, infer clear testable pointers without inventing unrelated scope.
- Optional first line may be exactly "Acceptance criteria" followed by a blank line, then only pointer lines.

Output ONLY a JSON object: {"acceptanceCriteria":"Acceptance criteria\\n\\nWhen ...\\nWhen ...","proposals":[{"id":"p1","summary":"...","testCaseType":"...","testFlow":"...","description":"..."}, ...]}. No markdown, no commentary outside the JSON.`;

  const user = `User story key: ${ctx.storyKey}
Story summary: ${ctx.storySummary}

Full story / acceptance text from JIRA:
---
${(ctx.descriptionPlain || '').slice(0, 120_000)}
---

Related issues (for context only):
${refText || '(none)'}

Sandbox / automation config excerpt (use for realistic test data names, URLs, picklists — do not invent secrets):
---
${flowSnippet || '(no flow-metadata file)'}
---

Produce the JSON object now (include "acceptanceCriteria" and "proposals").`;

  return { system, user };
}

function parseJsonFromText(content) {
  if (!content) throw new Error('Empty model response');
  let parsed;
  try {
    parsed = JSON.parse(stripJsonFence(content));
  } catch (e) {
    throw new Error(`Model content not valid JSON: ${e.message}`);
  }
  const proposals = normalizeProposals(parsed);
  if (!proposals) throw new Error('Model JSON missing proposals array');
  const acceptanceCriteria =
    parsed.acceptanceCriteria != null ? String(parsed.acceptanceCriteria).trim() : '';
  return { proposals, acceptanceCriteria };
}

async function generateProposalsGemini(ctx, projectRoot) {
  const key = (process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || '').trim();
  if (!key) return null;

  const model = (process.env.GEMINI_MODEL || 'gemini-flash-latest').trim();
  const { system, user } = buildPrompt(ctx, projectRoot);
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;

  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ parts: [{ text: user }] }],
    generationConfig: {
      temperature: 0.25,
      maxOutputTokens: 8192,
      responseMimeType: 'application/json',
    },
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Gemini response not JSON (${res.status}): ${raw.slice(0, 250)}`);
  }

  if (!res.ok) {
    const msg = data.error?.message || raw.slice(0, 400);
    throw new Error(`Gemini error ${res.status}: ${msg}`);
  }

  const parts = data.candidates?.[0]?.content?.parts;
  const text = Array.isArray(parts) ? parts.map((p) => p.text || '').join('') : '';
  return parseJsonFromText(text);
}

async function generateProposalsOllama(ctx, projectRoot) {
  const base = (process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');
  const model = (process.env.OLLAMA_MODEL || 'llama3.2').trim();
  const { system, user } = buildPrompt(ctx, projectRoot);

  const res = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      stream: false,
      format: 'json',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      options: { temperature: 0.25, num_predict: 8000 },
    }),
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Ollama response not JSON (${res.status}): ${raw.slice(0, 200)}`);
  }

  if (!res.ok) {
    throw new Error(`Ollama error ${res.status}: ${data.error || raw.slice(0, 200)}`);
  }

  const content = data.message?.content;
  return parseJsonFromText(content);
}

async function generateProposalsOpenAI(ctx, projectRoot) {
  const apiKey = (process.env.OPENAI_API_KEY || '').trim();
  if (!apiKey) return null;

  const model = (process.env.OPENAI_MODEL || 'gpt-4o-mini').trim();
  const baseUrl = (process.env.OPENAI_BASE_URL || OPENAI_DEFAULT_URL).replace(/\/$/, '');
  const url = baseUrl.endsWith('/chat/completions') ? baseUrl : `${baseUrl}/v1/chat/completions`;
  const { system, user } = buildPrompt(ctx, projectRoot);

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      temperature: 0.25,
      max_tokens: 16000,
      response_format: { type: 'json_object' },
    }),
  });

  const raw = await res.text();
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`OpenAI response not JSON (${res.status}): ${raw.slice(0, 200)}`);
  }

  if (!res.ok) {
    const msg = data.error?.message || data.message || raw.slice(0, 300);
    throw new Error(`OpenAI error ${res.status}: ${msg}`);
  }

  const content = data.choices?.[0]?.message?.content;
  return parseJsonFromText(content);
}

/**
 * @returns {Promise<{ proposals: object[], acceptanceCriteria: string, source: string }|null>}
 */
async function generateProposalsBestEffort(ctx) {
  const projectRoot = path.resolve(__dirname, '..', '..');
  const mode = (process.env.JIRA_PROPOSAL_LLM || 'auto').trim().toLowerCase();

  const tryGemini = async () => {
    const pack = await generateProposalsGemini(ctx, projectRoot);
    return pack
      ? { proposals: pack.proposals, acceptanceCriteria: pack.acceptanceCriteria || '', source: 'gemini' }
      : null;
  };
  const tryOllama = async () => {
    const pack = await generateProposalsOllama(ctx, projectRoot);
    return pack
      ? { proposals: pack.proposals, acceptanceCriteria: pack.acceptanceCriteria || '', source: 'ollama' }
      : null;
  };
  const tryOpenAI = async () => {
    if ((process.env.JIRA_PROPOSAL_USE_AI || '').trim() === '0') return null;
    const pack = await generateProposalsOpenAI(ctx, projectRoot);
    return pack
      ? { proposals: pack.proposals, acceptanceCriteria: pack.acceptanceCriteria || '', source: 'openai' }
      : null;
  };

  if (mode === 'none') return null;

  if (mode === 'gemini') {
    if (!(process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || '').trim()) {
      throw new Error('JIRA_PROPOSAL_LLM=gemini requires GEMINI_API_KEY (or GOOGLE_AI_API_KEY)');
    }
    return await tryGemini();
  }
  if (mode === 'ollama') {
    return await tryOllama();
  }
  if (mode === 'openai') {
    return await tryOpenAI();
  }

  // auto
  if ((process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || '').trim()) {
    try {
      const r = await tryGemini();
      if (r) return r;
    } catch (e) {
      console.warn('Gemini proposal generation failed, trying next:', e.message || e);
    }
  }

  const wantOllama =
    (process.env.JIRA_PROPOSAL_OLLAMA || '').trim() === '1' || !!(process.env.OLLAMA_MODEL || '').trim();
  if (wantOllama) {
    try {
      const r = await tryOllama();
      if (r) return r;
    } catch (e) {
      console.warn('Ollama proposal generation failed, trying next:', e.message || e);
    }
  }

  if ((process.env.OPENAI_API_KEY || '').trim() && (process.env.JIRA_PROPOSAL_USE_AI || '').trim() !== '0') {
    try {
      const r = await tryOpenAI();
      if (r) return r;
    } catch (e) {
      console.warn('OpenAI proposal generation failed:', e.message || e);
    }
  }

  return null;
}

/** Backward compat for scripts that only called OpenAI. */
async function generateProposalsFromStoryWithAI(ctx) {
  const projectRoot = path.resolve(__dirname, '..', '..');
  return generateProposalsOpenAI(ctx, projectRoot);
}

module.exports = {
  generateProposalsBestEffort,
  generateProposalsFromStoryWithAI,
  normalizeProposals,
  parseJsonFromText,
  generateProposalsGemini,
  generateProposalsOllama,
};
