/**
 * Print JSON context for drafting test proposals: story, existing tests on the story,
 * optional sibling stories on the same epic (best-effort JQL).
 *
 * Usage: node scripts/fetch-jira-proposal-context.js <STORY_KEY> > tests/jira-proposals/<STORY_KEY>/context-from-jira.json
 */

const path = require('path');

require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const {
  getClient,
  fetchStory,
  fetchTestCasesFromComments,
  fetchLinkedTestCases,
  fetchChildTestCases,
} = require('./jira/api');

async function searchIssuesByJql(client, jql, maxResults = 50) {
  const params = new URLSearchParams({
    jql,
    maxResults: String(maxResults),
    fields: 'summary,issuetype,key',
  });
  const data = await client.get(`/rest/api/3/search/jql?${params.toString()}`);
  return data.issues || data.values || [];
}

async function findEpicKey(client, storyKey) {
  const issue = await client.get(
    `/rest/api/3/issue/${encodeURIComponent(storyKey)}?fields=parent,issuelinks,summary`
  );
  const f = issue.fields || {};
  if (f.parent?.key) {
    try {
      const p = await client.get(
        `/rest/api/3/issue/${encodeURIComponent(f.parent.key)}?fields=issuetype`
      );
      const t = (p.fields?.issuetype?.name || '').toLowerCase();
      if (t.includes('epic')) return f.parent.key;
    } catch (_) {}
  }
  for (const link of f.issuelinks || []) {
    const n = (link.type?.name || '').toLowerCase();
    if (!n.includes('epic')) continue;
    const other = link.outwardIssue || link.inwardIssue;
    if (other?.key) return other.key;
  }
  return null;
}

async function siblingStories(client, epicKey, excludeKey) {
  const jqlAttempts = [
    `"Epic Link" = ${epicKey} ORDER BY key ASC`,
    `parent = ${epicKey} ORDER BY key ASC`,
    `issue in childIssuesOf(${epicKey}) ORDER BY key ASC`,
  ];
  for (const jql of jqlAttempts) {
    try {
      const issues = await searchIssuesByJql(client, jql, 80);
      const stories = issues
        .filter((i) => {
          const typeName = (i.fields?.issuetype?.name || '').toLowerCase();
          return (typeName.includes('story') || typeName.includes('task')) && i.key !== excludeKey;
        })
        .map((i) => ({
          key: i.key,
          summary: i.fields?.summary || '',
          type: i.fields?.issuetype?.name || '',
        }));
      if (stories.length) return { jqlUsed: jql, stories };
    } catch (e) {
      // try next JQL
    }
  }
  return { jqlUsed: null, stories: [] };
}

async function main() {
  const storyKey = process.argv[2];
  if (!storyKey) {
    console.error('Usage: node scripts/fetch-jira-proposal-context.js <STORY_KEY>');
    process.exit(1);
  }

  const client = getClient();
  const story = await fetchStory(client, storyKey);
  const comments = await fetchTestCasesFromComments(client, storyKey);
  const linked = await fetchLinkedTestCases(client, storyKey);
  const children = await fetchChildTestCases(client, storyKey);

  const epicKey = await findEpicKey(client, storyKey).catch(() => null);
  let epicContext = { epicKey: null, siblings: [] };
  if (epicKey) {
    const { jqlUsed, stories } = await siblingStories(client, epicKey, storyKey);
    epicContext = { epicKey, siblingQuery: jqlUsed, siblings: stories };
  }

  const out = {
    fetchedAt: new Date().toISOString(),
    story,
    existingTests: {
      fromComments: comments.map((c) => ({ key: c.key, summary: c.summary, source: c.source })),
      fromLinked: linked.map((c) => ({ key: c.key, summary: c.summary, source: c.source })),
      fromChildren: children.map((c) => ({ key: c.key, summary: c.summary, source: c.source })),
    },
    epicContext,
  };

  console.log(JSON.stringify(out, null, 2));
}

main().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
