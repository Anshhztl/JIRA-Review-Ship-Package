/**
 * Create JIRA Test issues for selected rows from a proposal folder.
 *
 * Prerequisite: proposal.json + selection.json in tests/jira-proposals/<STORY_KEY>/
 *
 * Usage: node scripts/push-proposal-selection-to-jira.js <STORY_KEY> [--dry-run] [--consume-selection]
 *
 * --consume-selection   After a successful run, rename selection.json so a second accidental push does nothing.
 *
 * Dedupes duplicate ids in selection.json and persists created-manifest.json after EACH issue
 * so a partial failure does not cause duplicate creates on re-run.
 */

const path = require('path');
const fs = require('fs');

require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const { getClient, createTestCaseIssue, ensureQaArtifactSubtasks } = require('./jira/api');

const projectRoot = path.resolve(__dirname, '..');

function writeManifest(manifestPath, parentStoryKey, createdRows) {
  const merged = {
    storyKey: parentStoryKey,
    updatedAt: new Date().toISOString(),
    created: createdRows,
  };
  fs.writeFileSync(manifestPath, JSON.stringify(merged, null, 2), 'utf8');
}

async function main() {
  const storyKey = process.argv[2];
  const dry = process.argv.includes('--dry-run');
  const consume = process.argv.includes('--consume-selection');
  if (!storyKey || storyKey.startsWith('-')) {
    console.error('Usage: node scripts/push-proposal-selection-to-jira.js <STORY_KEY> [--dry-run] [--consume-selection]');
    process.exit(1);
  }

  const dir = path.join(projectRoot, 'tests', 'jira-proposals', storyKey);
  const proposalPath = path.join(dir, 'proposal.json');
  const selectionPath = path.join(dir, 'selection.json');
  const manifestPath = path.join(dir, 'created-manifest.json');

  if (!fs.existsSync(proposalPath)) {
    console.error('Missing', proposalPath);
    process.exit(1);
  }
  if (!fs.existsSync(selectionPath)) {
    console.error(
      'Missing',
      selectionPath,
      `— export it from Test Proposals ~ ${storyKey}.html or create it manually.`
    );
    process.exit(1);
  }

  const proposal = JSON.parse(fs.readFileSync(proposalPath, 'utf8'));
  if (proposal.storyKey && proposal.storyKey !== storyKey) {
    console.warn(
      `Warning: proposal.json storyKey is ${proposal.storyKey} but folder is ${storyKey}. Using proposal.json storyKey for JIRA parent.`
    );
  }
  const parentStoryKey = proposal.storyKey || storyKey;

  const selection = JSON.parse(fs.readFileSync(selectionPath, 'utf8'));
  let selectedIds = selection.selectedIds;
  if (!Array.isArray(selectedIds) || !selectedIds.length) {
    console.error('selection.json must contain a non-empty selectedIds array.');
    process.exit(1);
  }

  selectedIds = [...new Set(selectedIds.map(String))];

  const byId = new Map((proposal.proposals || []).map((p) => [p.id, p]));
  const client = getClient();

  if (dry) {
    console.log('[dry-run] Would ensure QA artifact subtasks on', parentStoryKey);
  } else {
    console.log('Ensuring QA artifact subtasks on', parentStoryKey, '…');
    await ensureQaArtifactSubtasks(client, parentStoryKey);
  }

  let existing = [];
  if (fs.existsSync(manifestPath)) {
    try {
      const m = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      existing = Array.isArray(m.created) ? m.created : [];
    } catch (_) {}
  }

  const already = new Set(existing.map((x) => x.proposalId));
  const createdRows = [...existing];
  let newCount = 0;

  for (const id of selectedIds) {
    if (already.has(id)) {
      console.log('Skip (already in manifest):', id);
      continue;
    }
    const p = byId.get(id);
    if (!p) {
      console.warn('Unknown proposal id:', id);
      continue;
    }
    const summary = (p.summary || `Test — ${id}`).slice(0, 255);
    const descriptionPlain = (p.description || '').trim();
    if (dry) {
      console.log('[dry-run] Would create:', summary);
      continue;
    }
    const result = await createTestCaseIssue(client, parentStoryKey, summary, descriptionPlain, {
      testCaseType: String(p.testCaseType || '').trim(),
      testFlow: String(p.testFlow || '').trim(),
    });
    console.log('Created', result.key, result.linkedOnly ? '(linked to story)' : '', '—', summary);
    createdRows.push({ proposalId: id, jiraKey: result.key, summary });
    already.add(id);
    newCount += 1;
    writeManifest(manifestPath, parentStoryKey, createdRows);
    console.log('  (manifest saved)');
  }

  if (!dry && newCount > 0) {
    console.log('\nManifest:', manifestPath);
  } else if (!dry && newCount === 0) {
    console.log(
      '\nNo new test cases were created. Common reasons: every selected id is already in created-manifest.json, proposal ids in selection.json do not exist in proposal.json, or JIRA rejected all create attempts (see warnings above).'
    );
  }

  if (!dry && consume && newCount > 0 && fs.existsSync(selectionPath)) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const dest = path.join(dir, `selection.used-${stamp}.json`);
    fs.renameSync(selectionPath, dest);
    console.log('Renamed selection file to', path.basename(dest), '(use --consume-selection to avoid double-push).');
  }
}

main().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
