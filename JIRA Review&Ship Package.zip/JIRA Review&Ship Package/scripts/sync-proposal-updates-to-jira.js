/**
 * After you edit proposal.json (same proposal ids), push updated summary/description
 * to JIRA for issues listed in created-manifest.json.
 *
 * Usage: node scripts/sync-proposal-updates-to-jira.js <STORY_KEY> [--dry-run]
 */

const path = require('path');
const fs = require('fs');

require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const { getClient, updateIssueFields } = require('./jira/api');

const projectRoot = path.resolve(__dirname, '..');

async function main() {
  const storyKey = process.argv[2];
  const dry = process.argv.includes('--dry-run');
  if (!storyKey || storyKey.startsWith('-')) {
    console.error('Usage: node scripts/sync-proposal-updates-to-jira.js <STORY_KEY> [--dry-run]');
    process.exit(1);
  }

  const dir = path.join(projectRoot, 'tests', 'jira-proposals', storyKey);
  const proposalPath = path.join(dir, 'proposal.json');
  const manifestPath = path.join(dir, 'created-manifest.json');

  if (!fs.existsSync(proposalPath)) {
    console.error('Missing', proposalPath);
    process.exit(1);
  }
  if (!fs.existsSync(manifestPath)) {
    console.error('Missing', manifestPath, '— run jira:proposal:push first or add mapping manually.');
    process.exit(1);
  }

  const proposal = JSON.parse(fs.readFileSync(proposalPath, 'utf8'));
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const byId = new Map((proposal.proposals || []).map((p) => [p.id, p]));

  const client = getClient();

  for (const row of manifest.created || []) {
    const p = byId.get(row.proposalId);
    if (!p) {
      console.warn('No proposal row for id', row.proposalId, '(skipping)');
      continue;
    }
    const summary = (p.summary || '').slice(0, 255);
    const descriptionPlain = (p.description || '').trim();
    if (dry) {
      console.log('[dry-run] Would update', row.jiraKey, summary.slice(0, 60));
      continue;
    }
    await updateIssueFields(client, row.jiraKey, { summary, descriptionPlain });
    console.log('Updated', row.jiraKey, row.proposalId);
  }
}

main().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
