/**
 * Fetch a JIRA user story and write draft tests/jira-proposals/<KEY>/proposal.json (+ context, Test Proposals ~ <KEY>.html).
 * Uses numbered Acceptance Criteria lines when present; otherwise one draft + edge case.
 *
 * Usage: node scripts/jira-proposal-generate.js <STORY_KEY>
 */

const path = require('path');
const fs = require('fs');

require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const { getClient, issueDescriptionAsText } = require('./jira/api');
const { acceptanceCriteriaToLines } = require('./lib/acceptance-criteria-html');
const { buildReviewHtml } = require('./lib/proposal-review-html');
const { generateProposalsBestEffort } = require('./jira/proposal-llm');
const { getProposalTestCaseTypes, getProposalTestFlows } = require('./lib/jira-proposal-options');
const { reviewHtmlFileName } = require('./lib/jira-proposal-review-filename');

const projectRoot = path.resolve(__dirname, '..');

async function fetchIssueFull(client, key) {
  return client.get(
    `/rest/api/3/issue/${encodeURIComponent(key)}?fields=summary,description,issuetype,parent,issuelinks,project`
  );
}

function extractNumberedAC(plain) {
  const t = (plain || '').replace(/\r/g, '');
  const acMatch = t.match(/acceptance criteria[\s\S]*/i);
  const block = acMatch ? acMatch[0] : t;
  const items = [];
  const re = /^\s*(\d+)\.\s+(.+)$/gm;
  let m;
  while ((m = re.exec(block)) !== null) {
    items.push({ n: m[1], text: m[2].trim() });
  }
  return items;
}

/** Text for review UI: Jira "Acceptance criteria" section, else synthesized numbered AC. */
function extractAcceptanceCriteriaDisplay(plain) {
  const t = (plain || '').replace(/\r/g, '');
  const acMatch = t.match(/acceptance criteria[\s\S]*/i);
  if (acMatch) {
    const normalized = acceptanceCriteriaToLines(acMatch[0]).join('\n').trim();
    return normalized || acMatch[0].trim();
  }
  const numbered = extractNumberedAC(plain);
  if (numbered.length) {
    return `Acceptance criteria\n\n${numbered.map((it) => `${it.n}. ${it.text}`).join('\n')}`;
  }
  return '';
}

/** Normalize LLM acceptance criteria (strip markdown bullets, run through same line split as review UI). */
function normalizeAiAcceptanceCriteria(text) {
  const raw = String(text || '').trim();
  if (!raw) return '';
  const stripped = raw
    .split(/\n+/)
    .map((line) => line.replace(/^\s*[-*•]\s+/, '').trim())
    .filter(Boolean);
  const joined = stripped.join('\n');
  const lines = acceptanceCriteriaToLines(joined);
  return (lines.length ? lines.join('\n') : joined).trim();
}

function buildProposalsFromStory(storyKey, summary, plainDesc) {
  const numbered = extractNumberedAC(plainDesc);
  const proposals = [];
  const typeRotate = getProposalTestCaseTypes();
  const flowRotate = getProposalTestFlows();

  if (numbered.length) {
    numbered.forEach((it, idx) => {
      const id = `p${idx + 1}`;
      const sum = it.text.length > 120 ? `${it.text.slice(0, 117)}…` : it.text;
      const testCaseType = typeRotate[idx % typeRotate.length];
      const testFlow = flowRotate[idx % flowRotate.length];
      proposals.push({
        id,
        summary: sum,
        testCaseType,
        testFlow,
        description: `Preconditions/Test Data:
- CRM user logged into Salesforce Lightning with permissions for objects referenced in this criterion.
- Sandbox contains or can hold realistic test data (no production secrets).
- Duplicate / validation rules match the story (e.g. Name + Email or Phone) if applicable.

Steps:
1. Open the relevant app from the App Launcher (e.g. Sales).
2. Navigate to the object(s) implied by the story (Leads, Accounts, Contacts, etc.).
3. Perform the actions required to satisfy acceptance criterion ${it.n}: ${it.text}
4. Where relevant: create, edit, save, cancel, or trigger duplicate checks and capture UI messaging.
5. Verify persisted field values on the record detail view after save.

Expected Results:
- Behaviour matches acceptance criterion ${it.n} for this org configuration.
- Any duplicate or validation messaging is clear and consistent with the story.
- Note actual labels (e.g. Potential Duplicates, We found some possible matches) for the test evidence.`,
      });
    });
  } else {
    proposals.push({
      id: 'p1',
      summary: `Draft: ${summary}`.slice(0, 255),
      testCaseType: typeRotate[0],
      testFlow: flowRotate[0],
      description: `Preconditions/Test Data:
- CRM user in Salesforce Lightning.

Steps:
1. Read full story and acceptance in JIRA.
2. Perform an exploratory path covering the main goal.

Expected Results:
- Acceptance criteria satisfied.

---
Story excerpt:
${(plainDesc || '').slice(0, 2500)}`,
    });
  }

  const nextNum = proposals.length + 1;
  const edgeType = typeRotate[Math.min(2, typeRotate.length - 1)] || typeRotate[0];
  const edgeFlow = flowRotate[1] || flowRotate[0];
  proposals.push({
    id: `p${nextNum}`,
    summary: 'Edge — no false duplicate when duplicate keys differ',
    testCaseType: edgeType,
    testFlow: edgeFlow,
    description: `Preconditions/Test Data:
- Baseline records exist per story (e.g. Name + Email or Phone).

Steps:
1. Create or edit a record so only part of the duplicate key overlaps (per story intent).
2. Save or trigger duplicate logic.

Expected Results:
- No incorrect duplicate flag; or document org-specific fuzzy matching.`,
  });

  return proposals;
}

async function fetchSiblingRefs(client, epicKey, excludeKey) {
  const references = [];
  if (!epicKey) return references;
  references.push({ key: epicKey, note: 'parent epic' });
  try {
    const params = new URLSearchParams({
      jql: `parent = ${epicKey} AND issuetype = Story AND key != ${excludeKey} ORDER BY key ASC`,
      maxResults: '12',
      fields: 'summary',
    });
    const data = await client.get(`/rest/api/3/search/jql?${params.toString()}`);
    for (const i of data.issues || data.values || []) {
      references.push({
        key: i.key,
        summary: i.fields?.summary || '',
        note: 'sibling story on epic',
      });
    }
  } catch (_) {}
  return references;
}

async function main() {
  const storyKey = process.argv[2];
  if (!storyKey || storyKey.startsWith('-')) {
    console.error('Usage: node scripts/jira-proposal-generate.js <STORY_KEY>');
    process.exit(1);
  }

  const client = getClient();
  const issue = await fetchIssueFull(client, storyKey);
  const fields = issue.fields || {};
  const summary = fields.summary || storyKey;
  const plain = issueDescriptionAsText(fields.description);

  const parent = fields.parent;
  let epicKey;
  let epicSummary = '';
  if (parent?.key) {
    const pt = parent.fields?.issuetype?.name || '';
    if (/epic/i.test(pt)) {
      epicKey = parent.key;
      epicSummary = parent.fields?.summary || '';
    }
  }

  const references = await fetchSiblingRefs(client, epicKey, storyKey);
  if (epicKey && references.length && references[0].key === epicKey) {
    references[0].summary = epicSummary;
  }

  const llmDisabled = (process.env.JIRA_PROPOSAL_LLM || '').trim() === 'none';

  let proposals;
  let generatedBy = 'heuristic';
  let acceptanceCriteriaFromLlm = '';
  if (!llmDisabled) {
    try {
      const pack = await generateProposalsBestEffort({
        storyKey,
        storySummary: summary,
        descriptionPlain: plain,
        references,
      });
      if (pack && pack.proposals && pack.proposals.length) {
        proposals = pack.proposals;
        generatedBy = pack.source;
        acceptanceCriteriaFromLlm =
          pack.acceptanceCriteria != null ? String(pack.acceptanceCriteria).trim() : '';
        console.log(`Generated ${proposals.length} proposals via ${pack.source}.`);
      }
    } catch (e) {
      console.warn('LLM proposal generation failed, falling back to heuristic:', e.message || e);
    }
  }

  if (!proposals) {
    proposals = buildProposalsFromStory(storyKey, summary, plain);
    console.log(`Generated ${proposals.length} proposals via heuristic (numbered AC parser).`);
  }

  const sourceHint =
    generatedBy === 'heuristic'
      ? 'Free LLM: add GEMINI_API_KEY (Google AI Studio) or run Ollama locally (JIRA_PROPOSAL_OLLAMA=1). See docs/JIRA-TEST-CASE-PROPOSALS.md.'
      : `Draft from ${generatedBy} + flow-metadata excerpt. Review before JIRA push.`;

  const extracted = extractAcceptanceCriteriaDisplay(plain);
  const acFromAi = normalizeAiAcceptanceCriteria(acceptanceCriteriaFromLlm);
  const acceptanceCriteria = acFromAi || extracted;

  const proposalDoc = {
    storyKey,
    storySummary: summary,
    epicKey,
    contextNotes: sourceHint,
    references,
    acceptanceCriteria,
    proposals,
  };

  const storyDir = path.join(projectRoot, 'tests', 'jira-proposals', storyKey);
  fs.mkdirSync(storyDir, { recursive: true });

  const ctx = {
    generatedAt: new Date().toISOString(),
    storyKey,
    summary,
    epicKey: epicKey || null,
    descriptionPlainPreview: plain.slice(0, 1500),
  };
  fs.writeFileSync(path.join(storyDir, 'context-from-jira.json'), JSON.stringify(ctx, null, 2), 'utf8');
  fs.writeFileSync(path.join(storyDir, 'proposal.json'), JSON.stringify(proposalDoc, null, 2), 'utf8');

  const html = buildReviewHtml(proposalDoc, { pipeline: false });
  const reviewName = reviewHtmlFileName(storyKey);
  const reviewPath = path.join(storyDir, reviewName);
  const legacyReview = path.join(storyDir, 'review.html');
  if (fs.existsSync(legacyReview) && path.resolve(legacyReview) !== path.resolve(reviewPath)) {
    try {
      fs.unlinkSync(legacyReview);
    } catch (_) {}
  }
  fs.writeFileSync(reviewPath, html, 'utf8');

  console.log('Wrote:', path.join(storyDir, 'proposal.json'));
  console.log('Wrote:', reviewPath);
}

main().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
