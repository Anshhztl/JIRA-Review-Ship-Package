/**
 * Build a self-contained review page (Test Proposals ~ <KEY>.html) from tests/jira-proposals/<STORY_KEY>/proposal.json
 * (open in browser; no local server required — data is inlined).
 *
 * Usage: node scripts/build-proposal-review.js <STORY_KEY>
 *    or: node scripts/build-proposal-review.js --path path/to/proposal.json
 */

const path = require('path');
const fs = require('fs');

const projectRoot = path.resolve(__dirname, '..');
const { buildReviewHtml } = require('./lib/proposal-review-html');
const { reviewHtmlFileName } = require('./lib/jira-proposal-review-filename');

function loadProposal(storyKeyOrPath) {
  if (storyKeyOrPath.startsWith('--path')) {
    const p = process.argv[3];
    if (!p) throw new Error('Missing path after --path');
    return { file: path.resolve(p), storyDir: path.dirname(path.resolve(p)) };
  }
  const key = storyKeyOrPath;
  const storyDir = path.join(projectRoot, 'tests', 'jira-proposals', key);
  const file = path.join(storyDir, 'proposal.json');
  return { file, storyDir };
}

function validateProposal(data) {
  if (!data || typeof data !== 'object') throw new Error('proposal.json must be an object');
  if (!data.storyKey) throw new Error('proposal.json: missing storyKey');
  if (!Array.isArray(data.proposals)) throw new Error('proposal.json: proposals must be an array');
  for (const p of data.proposals) {
    if (!p.id) throw new Error('Each proposal needs id');
    if (!p.summary && !p.description) throw new Error(`Proposal ${p.id}: need summary or description`);
  }
}

function main() {
  const arg = process.argv[2];
  if (!arg) {
    console.error('Usage: node scripts/build-proposal-review.js <STORY_KEY>');
    console.error('   or: node scripts/build-proposal-review.js --path path/to/proposal.json');
    process.exit(1);
  }
  const { file, storyDir } = loadProposal(arg);
  if (!fs.existsSync(file)) {
    console.error('Missing file:', file);
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  validateProposal(data);
  const html = buildReviewHtml(data, { pipeline: false });
  const reviewName = reviewHtmlFileName(data.storyKey);
  const out = path.join(storyDir, reviewName);
  const legacy = path.join(storyDir, 'review.html');
  if (fs.existsSync(legacy) && path.resolve(legacy) !== path.resolve(out)) {
    try {
      fs.unlinkSync(legacy);
    } catch (_) {}
  }
  fs.mkdirSync(storyDir, { recursive: true });
  fs.writeFileSync(out, html, 'utf8');
  console.log('Wrote', out);
  console.log('Open this file in your browser to select test cases.');
}

main();